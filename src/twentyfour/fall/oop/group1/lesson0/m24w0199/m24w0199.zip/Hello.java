
package twentyfour.fall.oop.group1.lesson0.m24w0199;
public  class Hello{
    public static void main(String[] args){
        System.out.println("Hello Java Class");
    }
}